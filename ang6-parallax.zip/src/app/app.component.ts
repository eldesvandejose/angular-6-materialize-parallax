import { Component, OnInit } from '@angular/core';

declare var $: any;

@Component({
  selector: 'a6plx-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  constructor () { }

  ngOnInit() {
    $(document).ready(function() {
      $('.parallax').parallax();
    });
  }
}
